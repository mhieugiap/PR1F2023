package Tutorial.TUT6.Instruct;

public class PersonDemo {
    public static void main(String[] args) {
        Person personA = new Person();
        personA.name = "A";
        personA.age = 20;
        Person personB = new Person("B", 21);
        personA.greeting();
        personB.greeting();
    }
}
