package Tutorial.TUT13.Demo;

import Tutorial.TUT13.BlankWindow.BlankPanel;

import javax.swing.*;
import java.awt.*;
import java.io.IOException;

public class Demo {
    public static void main(String[] args) throws IOException {
       JFrame f = new JFrame("Demo");
       JPanel p = new DemoPanel();
       f.add(p);
       f.pack();
       f.setLocationRelativeTo(null);
       f.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
       f.setVisible(true);
    }
}
