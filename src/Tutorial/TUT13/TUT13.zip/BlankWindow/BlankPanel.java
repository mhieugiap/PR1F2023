package Tutorial.TUT13.BlankWindow;

import javax.swing.*;
import java.awt.*;

public class BlankPanel extends JPanel {
    public BlankPanel(){
        setPreferredSize(new Dimension(480,360));
    }

    @Override
    public void paintComponent(Graphics g) {

    }
}
